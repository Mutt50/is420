async function loadJSON() {
    {
      const response = await fetch("./inventory.json");
      const json = await response.json();
      products = json;
    }
  {
    const response = await fetch("./users.json");
    const json = await response.json();
    users = json;
  }
}

var products = {};
var users = {};

loadJSON().then(() => {
	buildFeatured();
	buildProducts(products);
	buildProductDetails();
	buildCart();
  buildAccount();
  buildLogin();
  buildOrderHistory();
  buildAddresses();
  buildPaymentMethods();
});

function buildFeatured() {

  if ( window.location.href.indexOf("home.html") == -1 ) return;

	let cs = document.querySelector(".featured");

	if (!cs) return;

	const numberToShow = 6;
	let arr = [];
	for (var i=0;i<numberToShow;i++) {
		arr.push(products[Math.floor(Math.random()*products.length)]);
	}

	arr.forEach( (p, index) => {

		let c = cs;
		if ( index != 0 ) {
			c = cs.cloneNode(true);
			cs.parentNode.appendChild(c);
		} 
		let img = c.querySelector('.product IMG');
		let rev = c.querySelector('.reviewText');
		let rate = c.querySelector('.rating');
		let name = c.querySelector('.name');

		rate.innerText = "★★★★☆";
		rev.innerText = lorem;
		name.innerText = p.Name;

		// let a = document.createElement('a');
		// a.href = "product_details.html?id=" + p.id;

		// c.parentNode.insertBefore(a, c);
		// a.appendChild(c);

		c.onclick = function() {
			window.location.href = "product_details.html?product_id=" + p.product_id;
		}

	})
}

function buildProducts(ps) {

  if ( window.location.href.indexOf("products.html") == -1 ) return;

	let cs = document.querySelector(".product");

	if (!cs) return;
	
	ps.forEach( (p, index) => {

		let c = cs;
		if ( index != 0 ) {
			c = cs.cloneNode(true);
			cs.parentNode.appendChild(c);
		} 
		let img = c.querySelector('.product IMG');
		let price = c.querySelector('.price');
		let rate = c.querySelector('.rating');
		let name = c.querySelector('.name');

		let form = c.querySelector('form');
		form.product_id.value = p.product_id;

		rate.textContent = "★★★★☆";
		price.textContent = "$" + p["Price ($)"].toFixed(2);
		name.textContent = p.Name;
    form.product_id.value = p.product_id;
    if (p.Colors) form.color.value = p.Colors.split(",")[0].trim();
    if (p.Sizes) form.size.value = p.Sizes.split(",")[0].trim();

    let b_addToCart = form.querySelector(".addToCart");

    b_addToCart.onclick = function() {
      addToCart(form);
    }
  
		name.onclick = function() {
			window.location.href = "product_details.html?product_id=" + p.product_id;
		}

	})
}

function buildProductDetails(id) {

  if ( window.location.href.indexOf("product_details.html") == -1 ) return;

	let c = document.querySelector(".productDetails");

	if (!c) return;

	const urlParams = new URLSearchParams(window.location.search);
	const product_id = urlParams.get('product_id');

	if ( !product_id ) return;

	let p = products.find(_p => _p.product_id == product_id);

	let img = c.querySelector('.image IMG');
	let price = c.querySelector('.price');
	let rate = c.querySelector('.rating');
	let name = c.querySelector('.name');
	let desc = c.querySelector(".description");

	rate.innerText = "★★★★☆";
	price.innerText = "$" + p["Price ($)"].toFixed(2);
	name.innerText = p.Name;
	desc.innerText = lorem;

	let form = c.querySelector('form');
	form.product_id.value = p.product_id;

	p.Colors.split(",").forEach( _c => {
		let o = document.createElement('option');
		o.value = _c.trim();
		o.textContent = _c.trim();
		form.color.appendChild(o);
	});

	p.Sizes.split(",").forEach( _c => {
		let o = document.createElement('option');
		o.value = _c.trim();
		o.textContent = _c.trim();
		form.size.appendChild(o);
	});

	let related = products.filter(_p => {
		return _p.Category == p.Category && _p != p
	});

	let orig = document.querySelector(".relatedProduct");

	for ( let i=0;i<Math.min(related.length, 6);i++) {
		let r = orig.cloneNode(true);

		r.title = related[i].Name;

		r.onclick = function() {
			window.location.href = "product_details.html?product_id=" + related[i].product_id;
		}

		orig.parentNode.appendChild(r);
	}

	orig.parentNode.removeChild(orig);

	let b_addToCart = form.querySelector(".addToCart");

	b_addToCart.onclick = function() {
		addToCart(form);
	}
}

function getCart() {
	let cart = window.sessionStorage.getItem("cart");
	cart = cart && cart != null ? JSON.parse(window.sessionStorage.getItem("cart")) : [];
	return cart;
}

function getUser() {
  let user = window.sessionStorage.getItem("user"); 
  user = user && user != null ? JSON.parse(user) : null;
  return user;
}

function addToCart(form) {
	let item = {
		product_id: form.product_id.value,
		color: form.color.value,
		size: form.size.value,
		quantity:form.quantity.value
	}

	let cart = getCart();

	cart.push(item);
	window.sessionStorage.setItem("cart", JSON.stringify(cart)); 

	console.log("Current cart: ");
	console.log(window.sessionStorage.getItem("cart"));

  alert("Added to cart!");

  // let modal = `<!-- Modal -->
    
  //     <!-- Modal content-->
  //     <div class="modal-content">
  //       <div class="modal-header">
  //         <button type="button" class="close" data-dismiss="modal">&times;</button>
  //         <h4 class="modal-title">Modal Header</h4>
  //       </div>
  //       <div class="modal-body">
  //         <p>Some text in the modal.</p>
  //       </div>
  //       <div class="modal-footer">
  //         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  //       </div>
  //     </div>`;

  // let modalDiv = document.createElement('dialog');
  // modalDiv.innerHTML = modal;
  // document.body.appendChild(modalDiv); 

  // modalDiv.showModal();
}

function updateCart(item) {
  let cart = getCart();

  for (let i=0;i<cart.length;i++ ) {

    if ( cart[i].product_id === item.product_id ) {
      cart[i] = item;
      break;
    }
  }

  window.sessionStorage.setItem("cart", JSON.stringify(cart));
  return cart;
}

function buildCart() {

  if ( window.location.href.indexOf("cart.html") == -1 ) return;

	let orig = document.querySelector(".cartItem");

	if ( !orig ) return;

	let cart = getCart();

  if ( cart.length == 0 ) {
    document.querySelector(".cart").innerHTML = `
      <h2>Your cart is empty</h2>
      <p>Looks like you haven't added anything to your cart yet. Start shopping now!</p>
      <a href="products.html" class="btn btn-primary">Shop Now</a>
    `;
    orig.parentNode.appendChild(empty);
    return;
  }

  function getSubTotal() {
    let subTotal = 0;
    cart.forEach( item => {
      let product = products.find(p => p.product_id == item.product_id);
      item.product = product;

      subTotal += product["Price ($)"] * item.quantity;
    });

    return subTotal;
  }

  function setValues(row, item) {
    let product = products.find(p => p.product_id == item.product_id);
    row.querySelector(".name").textContent = product.Name;
    row.querySelector(".product_id").value = product.product_id;
    row.querySelector(".price").textContent = "$" + product["Price ($)"].toFixed(2);
    row.querySelector(".color").textContent = item.color;
    row.querySelector(".size").textContent = item.size;
    row.querySelector(".quantity").value = item.quantity;
  }

	cart.forEach( item => {
		let c = orig.cloneNode(true);

		orig.parentNode.appendChild(c);

		let product = products.find(p => p.product_id == item.product_id);

		if ( !product ) {
			console.error("no product matching id: " + p.product_id);
			return;
		}

    setValues(c, item);

    // listen for changes
    c.querySelector(".quantity").onchange = function() {
      item.quantity = parseInt(c.querySelector(".quantity").value);
      updateCart(item);
      setValues(c, item);
      setTotals();
    }

	});

  setTotals();

	orig.parentNode.removeChild(orig);

  function setTotals() {
    // subtotals
    let totalsDiv= document.querySelector(".cart .totals");


    let subTotal = getSubTotal();
    let tax = (subTotal*0.065);
    let shipping = 10.50
    let total = (subTotal + tax + shipping);

    totalsDiv.innerText = `
      Subtotal: $${subTotal.toFixed(2)}
      Tax: $${tax.toFixed(2)}
      Shipping: $${shipping.toFixed(2)}
      Total: $${total.toFixed(2)}
    `;

}

	// set checkout options
	if ( getUser() )
		document.querySelector(".checkoutOptions .loggedOut").style.display = 'none';
  else
    document.querySelector(".checkoutOptions .loggedIn").style.display = 'none';
}

function buildAccount() {

  if ( window.location.href.indexOf("account.html") == -1 ) return;

  let user = getUser();

  // redirect if not logged in
  if ( !user ) {
    window.location.href = "login.html";
  }

  document.querySelector(".logout").onclick = function() {
    logout();
    window.location.reload();
  }

}

function buildLogin() {

  if ( window.location.href.indexOf("login.html") == -1 ) return;

  // logged in
  if ( window.sessionStorage.getItem("user") ) return;

  let form = document.querySelector("#loginForm");

  form.action = "javascript:void(0);";
  form.onsubmit = function(e) {

    let email = form.email;
    let password = form.password;

    let user = users.find( u => u.email == email.value && u.password == password.value );

    if ( user ) {
      window.sessionStorage.setItem("user", JSON.stringify(user));

      const urlParams = new URLSearchParams(window.location.search);
      const ref = urlParams.get('ref');
      window.location.href = ref || "home.html";
    }
    else {
        alert("Invalid email or password. Please try again.");
      }
    }

    return false;
}

function logout() { 
  window.sessionStorage.removeItem("user");
  window.sessionStorage.clear();
 }

 function buildOrderHistory() {
  if ( window.location.href.indexOf("order_history.html") == -1 ) return;

  let user = getUser();
  if ( !user ) {
    window.location.href = "login.html"; 
  }

  orders = user.order_history;

  let orig = document.querySelector(".order");

  orders.forEach( item => {
    let c = orig.cloneNode(true);

    orig.parentNode.appendChild(c);

    c.querySelector(".order_id").textContent = item.order_id;
    c.querySelector(".date").textContent = item.date;
    c.querySelector(".status").textContent = item.status || "Pending";
    c.querySelector(".total").textContent = "$" + item.total.toFixed(2);
    c.querySelector(".details").textContent = "Details";
  })

  // orig.parentNode.removeChild(orig);
 }

function buildAddresses() {
  if ( window.location.href.indexOf("address.html") == -1 ) return;

  let user = getUser();
  if ( !user ) {
    window.location.href = "login.html"; 
  }

  let orig = document.querySelector(".address");

  user.addresses.forEach( (item, index) => {
    let c = orig.cloneNode(true);

    orig.parentNode.insertBefore(c, orig);

    c.querySelector(".name").textContent = item.name;
    c.querySelector(".street").textContent = item.street;
    c.querySelector(".city").textContent = [item.city, item.state, item.zip].join(" ");

    if ( index == 0 )
      c.querySelector("INPUT[type='radio']").checked = true;
  })

  orig.parentNode.removeChild(orig);
 }

function buildPaymentMethods() {
  if ( window.location.href.indexOf("payment.html") == -1 ) return;

  let user = getUser();
  if ( !user ) {
    window.location.href = "login.html"; 
  }

  let orig = document.querySelector(".paymentMethod");

  user.payment_methods.forEach( (item, index) => {
    let c = orig.cloneNode(true);

    orig.parentNode.insertBefore(c, orig);

    if ( item.type == "card") {
      let card = item.card;
      let billing = item.billing_details;


      c.querySelector(".name").textContent = billing.name;
      c.querySelector(".street").textContent = card.brand;
      c.querySelector(".city").textContent = card.last4;
    } else if (item.type == "sepa_debit") {
      let debit = item.sepa_debit;
      c.querySelector(".name").textContent = "Bank Account";
      c.querySelector(".street").textContent = debit.bank_code;
    }

    if ( index == 0 )
      c.querySelector("INPUT[type='radio']").checked = true;
  })

  orig.parentNode.removeChild(orig);
 }

var lorem = `Lorem ipsum dolor sit amet consectetur adipiscing elit. Quisque faucibus ex sapien vitae pellentesque sem placerat. In id cursus mi pretium tellus duis convallis. Tempus leo eu aenean sed diam urna tempor. Pulvinar vivamus fringilla lacus nec metus bibendum egestas. Iaculis massa nisl malesuada lacinia integer nunc posuere. Ut hendrerit semper vel class aptent taciti sociosqu. Ad litora torquent per conubia nostra inceptos himenaeos.`;

function randomDiscounts() {
  products.forEach((p,i,a) => {

    let ds = [5, 10, 15, 20];
    if ( Math.random() > .8) {
       a[i].Discount = ds[Math.floor(Math.random() * ds.length)];
    } else
      a[i].Discount = 0;
  
  })
}

